import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

const MIN_N = 2;
const MAX_N = 21;

interface AutomatonStore {
    n: number,
    setN: (n: number) => void,

    displayText: string,
    setDisplayText: (text: string) => void,

    brushSize: number,
    setBrushSize: (x: number) => void,

    primaryColour: {h: number, s: number, l: number},
    setPrimaryColour: (key: string, value: number) => void,

    distinguishZeroColour: boolean,
    setDistinguishZeroColour: (val: boolean) => void,

    distinguishMaxColour: boolean,
    setDistinguishMaxColour: (val: boolean) => void,

    colouringStyle: string,
    setColouringStyle: (s: string) => void,
}

export const useAutomatonStore = create<AutomatonStore>()(
    subscribeWithSelector((set) => ({
    n: 2,
    setN: (n: number) => set((s) => { 
        if (n >= MIN_N && n <= MAX_N) {
            return {n: n}
        } else {
            return {n: s.n}
        }
    }),

    displayText: "",
    setDisplayText: (text: string) => set({displayText: text}),

    brushSize: 5,
    setBrushSize: (x: number) => set({brushSize: x}),

    primaryColour: {h: 0, s: 0, l: 0},
    setPrimaryColour: (key: string, value: number) => set((s) => ({primaryColour: {...s.primaryColour, [key]: value}})),

    distinguishZeroColour: true,
    setDistinguishZeroColour: (val: boolean) => set({distinguishZeroColour: val}),
    
    distinguishMaxColour: false,
    setDistinguishMaxColour: (val: boolean) => set({distinguishMaxColour: val}),
    
    colouringStyle: "radialSpread",
    setColouringStyle: (s: string) => set({colouringStyle: s}),
})));