import React from 'react';
import { useRef, useState, type RefObject } from 'react';
import { Automaton } from '../automaton.ts';

const MAX_VIDEO_BYTES = 30 * 1024 * 1024;

interface playbackPanelProps{
    simulation: Automaton,
    cRef: RefObject<HTMLCanvasElement | null>
}

const PlaybackPanel: React.FC<playbackPanelProps> = ({
    simulation,
    cRef,
}) => {
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const chunksRef = useRef<Blob[]>([]);

    const [isRecording, setIsRecording] = useState<boolean>(false);
    const [videoSize, setVideoSize] = useState<number>(0);

    const toggleRecording = () => {
        setIsRecording((recording: boolean) => {
            if (recording) {
                mediaRecorderRef.current?.stop()!;
                setIsRecording(false);
            } else {
                chunksRef.current = [];

                const stream = cRef.current?.captureStream(30)!;

                const mediaRecorder = new MediaRecorder(stream, {
                    videoBitsPerSecond: 12_000_000,
                    mimeType: 'video/webm;codecs=vp9',
                })

                mediaRecorder.ondataavailable = (e) => {
                    if (e.data.size > 0){
                        chunksRef.current.push(e.data);
                        setVideoSize((size) => size + e.data.size);
                    }
                    console.log(videoSize, MAX_VIDEO_BYTES);
                    if (videoSize > MAX_VIDEO_BYTES) {
                        mediaRecorderRef.current?.stop();
                    }
                };

                mediaRecorder.onstop = () => {
                    const blob = new Blob(chunksRef.current, { type: 'video/webm' });
                    const url = URL.createObjectURL(blob);
                    downloadFile(url, 'video.webm');
                    setVideoSize(0);
                };

                mediaRecorder.start(500);
                mediaRecorderRef.current = mediaRecorder;
                // setTimeout(() => {
                //     if (mediaRecorder.state !== 'inactive') {
                //         mediaRecorder.stop();
                //     }
                // }, 10000);
            }
            return ! recording;
        })
    }

    const screenshot = () => {
        const dataUrl = cRef.current?.toDataURL()!;
        downloadFile(dataUrl, 'screenshot.png');
        
        // const downloadLink = document.createElement('a');
        // downloadLink.href = dataUrl;
        // downloadLink.download = 'screenshot.png';
    
        // document.body.appendChild(downloadLink);
        // downloadLink.click();
        // document.body.removeChild(downloadLink);
    }

    const downloadFile = (url: string, filename: string) => {
        const downloadLink = document.createElement('a');
        downloadLink.href = url;
        downloadLink.download = filename;
    
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
    }
    
    return <div className="panel-horizontal">
        <div className="control-column playback-column">
            <button onClick={() => toggleRecording()}>&#128308;</button>
            <button onClick={() => simulation.stepSim()}>&#8658;</button>
            <button onClick={() => simulation.togglePlay()}>&#9199;</button>
            <button onClick={screenshot}>&#x1F4F7;</button>
        </div>
    </div>
};

export default React.memo(PlaybackPanel);